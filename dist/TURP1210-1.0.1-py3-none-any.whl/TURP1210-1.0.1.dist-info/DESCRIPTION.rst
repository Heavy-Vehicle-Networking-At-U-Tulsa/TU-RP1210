A setuptools based setup module for TU RP1210


